package wsrest;

import org.springframework.data.repository.CrudRepository;

public interface AssociadoRepo extends CrudRepository<Associado, Long>{
	
}
