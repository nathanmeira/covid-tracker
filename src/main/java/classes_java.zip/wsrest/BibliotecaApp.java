package wsrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaApp {
	public static void main(String[] args) {
		SpringApplication.run(BibliotecaApp.class, args);
	}
}
